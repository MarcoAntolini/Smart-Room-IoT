#ifndef __VARIABLES__
#define __VARIABLES__

#define btrx 2
#define bttx 3

#define ledPin 13

#define rBlindsPin 3

#endif